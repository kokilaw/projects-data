self.__precacheManifest = [
  {
    "revision": "e63b93dfac2600782654e2b87910d681",
    "url": "/static/media/Poppins-SemiBold.e63b93df.ttf"
  },
  {
    "revision": "731a28a413d642522667a2de8681ff35",
    "url": "/static/media/Poppins-Regular.731a28a4.ttf"
  },
  {
    "revision": "a4e11dda40531debd374e4c8b1dcc7f4",
    "url": "/static/media/Poppins-Medium.a4e11dda.ttf"
  },
  {
    "revision": "7940efc40d8e3b477e16cc41b0287139",
    "url": "/static/media/Poppins-Bold.7940efc4.ttf"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f9472d9213c6b208c9fa",
    "url": "/static/js/main.dfe35b06.chunk.js"
  },
  {
    "revision": "045d5d9b664fe3155c32",
    "url": "/static/js/2.86e23c47.chunk.js"
  },
  {
    "revision": "f9472d9213c6b208c9fa",
    "url": "/static/css/main.c89136d9.chunk.css"
  },
  {
    "revision": "2af6709e4d4f49ba40f1900979d24133",
    "url": "/index.html"
  }
];